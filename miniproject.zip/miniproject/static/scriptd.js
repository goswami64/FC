let Totalincome = 0;
let Totalexpense = 0;
function update(){
    document.getElementById("TI").innerText = Totalincome;
    document.getElementById("TE").innerText = Totalexpense;
    document.getElementById("TS").innerText = Totalincome - Totalexpense;
}
function incomeForm(){
    document.getElementById("pop1").style.display = "block";
    document.getElementById("overlay").style.display = "block";
}
function expenseform(){
    document.getElementById("pop2").style.display = "block";
    document.getElementById("overlay").style.display = "block";
}
function closeform(){
       document.getElementById("overlay").style.display = "none";
    document.getElementById("pop1").style.display = "none";
    document.getElementById("pop2").style.display = "none";
    document.getElementById("incomeform").reset();
    document.getElementById("expenseform").reset();
    
}
document.getElementById("incomeform").addEventListener("submit", function(event) {
 event.preventDefault();

const Income =document.getElementById("Income").value;
const Amountt= parseFloat(document.getElementById("Iamount").value);
const date = document.getElementById("date1").value;
const discription = document.getElementById("de1").value;
 
const table = document.getElementById("dtable");
const newRow = table.insertRow(-1);
newRow.insertCell(0).innerText = Income;
newRow.insertCell(1).innerText = Amountt;
newRow.insertCell(2).innerText = date;
newRow.insertCell(3).innerText = discription;
Totalincome+=Amountt;
update();
closeform();
});

document.getElementById("Expenseform").addEventListener("submit", function(event1) {
    event1.preventDefault();
   
   const Expense =document.getElementById("expense").value;
   const Amount1= parseFloat(document.getElementById("Eamount").value);
   const date2 = document.getElementById("date2").value;
   const discription1 = document.getElementById("de2").value;
    
   const table = document.getElementById("dtable");
   const newRow = table.insertRow(-1);
   newRow.insertCell(0).innerText = Expense;
   newRow.insertCell(1).innerText = Amount1;
   newRow.insertCell(2).innerText = date2;
   newRow.insertCell(3).innerText = discription1;
   Totalexpense+=Amount1;
   update();
   closeform();
   });
 
  

   
   